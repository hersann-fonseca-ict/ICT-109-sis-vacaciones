prompt --application/shared_components/logic/application_processes/prc_devuelve_rol
begin
--   Manifest
--     APPLICATION PROCESS: PRC_DEVUELVE_ROL
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(219899459619828501)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DEVUELVE_ROL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* proceso ',
'llamado del SP y le asigno el valor devuelvo a la variable global',
':GLOBAL_PERMISO := llamado SP',
'',
'*/',
'BEGIN',
'    --:GLOBAL_ROL := null;',
'    :GLOBAL_ROL := TEST_SEGURIDAD.PKG_LOGUEO.validarLogueo(1, :APP_USER);',
'END;'))
);
wwv_flow_api.component_end;
end;
/
