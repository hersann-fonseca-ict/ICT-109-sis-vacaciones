prompt --application/shared_components/reports/report_queries/1
begin
--   Manifest
--     WEB SERVICE: 1
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_shared_query(
 p_id=>wwv_flow_api.id(46164149081248975)
,p_name=>'1'
,p_query_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select e.id_empleado, e.cedula, (e.nombre|| '' '' || e.primer_apellido || '' '' || e.segundo_apellido) as "Nombre Completo", ',
unistr('CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv',
'where e.id_empleado = sv.id_empleado and sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'order by CAST(sv.fecha_inicio AS DATE) desc'))
,p_xml_structure=>'STANDARD'
,p_format=>'PDF'
,p_output_file_name=>'1'
,p_content_disposition=>'ATTACHMENT'
);
wwv_flow_api.component_end;
end;
/
