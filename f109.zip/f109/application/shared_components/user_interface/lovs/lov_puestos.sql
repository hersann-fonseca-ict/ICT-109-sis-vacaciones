prompt --application/shared_components/user_interface/lovs/lov_puestos
begin
--   Manifest
--     LOV_PUESTOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(197096954531454781)
,p_lov_name=>'LOV_PUESTOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P.CODIGO_PRESUPUESTARIO||'' - ''||CP.NOMBRE nombre,P.ID_PUESTO ',
' from CLASES_PUESTO CP,PUESTOS P',
' where CP.ID_MANUAL_PUESTO = P.ID_MANUAL_PUESTO',
' AND   CP.ID_CLASE_PUESTO = P.ID_CLASE_PUESTO'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_owner=>'DESA_RH'
,p_return_column_name=>'ID_PUESTO'
,p_display_column_name=>'NOMBRE'
,p_default_sort_column_name=>'NOMBRE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
