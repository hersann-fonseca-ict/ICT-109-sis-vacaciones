prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'Informacion Saldo de Vacaciones Legales'
,p_alias=>'132-INFORMACION-SALDO-DE-VACACIONES-LEGALES'
,p_step_title=>'132-Informacion Saldo de Vacaciones Legales'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241030152301'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(739119041608711297)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(739122165877711329)
,p_plug_name=>'Periodo de Vacaciones'
,p_parent_plug_id=>wwv_flow_api.id(739119041608711297)
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(739119115742711298)
,p_plug_name=>'Reporte Periodo de Vacaciones'
,p_parent_plug_id=>wwv_flow_api.id(739122165877711329)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188326824198098128)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROWID,',
'       ID_INSTITUCION_SIRHP,',
'       ID_EMPLEADO,',
'       INICIO_PERIODO || '' - '' || FIN_PERIODO PERIODO,',
'       INICIO_PERIODO, ',
'       FIN_PERIODO,',
'       ACREDITADAS_HABILES,',
'       ID_BITACOR_ACREDITACIO_VACACIO,',
'       SALDO_HABIL,',
'       ID_MODIFICADOR,',
'       FECHA_ULTIMA_MODIFICACION',
'  FROM SALDO_VACACIONES_LEGALES',
' WHERE ID_EMPLEADO = :P5_ID_EMPLEADO'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P5_ID_EMPLEADO'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte Periodo de Vacaciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(189315237517749243)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_detail_link=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::P400_CEDULA,P400_PERIODO_INICIO,P400_PERIODO_FIN:&P5_CEDULA.,#INICIO_PERIODO#,#FIN_PERIODO#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>189315237517749243
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315388310749244)
,p_db_column_name=>'ROWID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315433200749245)
,p_db_column_name=>'ID_INSTITUCION_SIRHP'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Institucion Sirhp'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315523556749246)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Id Empleado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315608994749247)
,p_db_column_name=>'PERIODO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315798936749248)
,p_db_column_name=>'ACREDITADAS_HABILES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('D\00EDas Acreditados')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315811646749249)
,p_db_column_name=>'ID_BITACOR_ACREDITACIO_VACACIO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Id Bitacor Acreditacio Vacacio'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(189315935011749250)
,p_db_column_name=>'SALDO_HABIL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Saldo H\00E1bil')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199682799952731501)
,p_db_column_name=>'ID_MODIFICADOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Id Modificador'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199682868803731502)
,p_db_column_name=>'FECHA_ULTIMA_MODIFICACION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Fecha \00DAltima Modificaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199788244558623906)
,p_db_column_name=>'INICIO_PERIODO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Inicio Periodo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199788385893623907)
,p_db_column_name=>'FIN_PERIODO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fin Periodo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(199695163996732204)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1996952'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ROWID:ID_INSTITUCION_SIRHP:ID_EMPLEADO:PERIODO:ACREDITADAS_HABILES:ID_BITACOR_ACREDITACIO_VACACIO:SALDO_HABIL:ID_MODIFICADOR:FECHA_ULTIMA_MODIFICACION:INICIO_PERIODO:FIN_PERIODO'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(904747529287114915)
,p_plug_name=>unistr('Informaci\00F3n General del Empleado')
,p_parent_plug_id=>wwv_flow_api.id(739119041608711297)
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(914052809379447267)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(739119041608711297)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Informaci\00F3n de Vacaciones por Funcionario</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192333331533602216)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(914052809379447267)
,p_button_name=>'Solicitud_de_Vacaciones'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(188390967782098191)
,p_button_image_alt=>'Solicitud De Vacaciones'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,:P101_CEDULA,P101_PERIODO:&P5_CEDULA.,&P5_PERIODO.#P5_CEDULA#\#P5_ID_EMPLEADO#\'
,p_icon_css_classes=>'fa-plane'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(46297993882096924)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(914052809379447267)
,p_button_name=>'Solicitud_Devolucion'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(188390967782098191)
,p_button_image_alt=>'Modifique sus Vacaciones'
,p_button_position=>'BOTTOM'
,p_button_redirect_url=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.:RP,:P403_CEDULA:&P5_CEDULA.#P5_CEDULA#\#P5_ID_EMPLEADO#\'
,p_icon_css_classes=>'fa-reply-all'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(192303950050258123)
,p_branch_name=>'Go To Page 117'
,p_branch_action=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NEVER'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46295823786096903)
,p_name=>'P5_PERIODO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('Periodo h\00E1bil')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192290504956258093)
,p_name=>'P5_ID_EMPLEADO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Empleado'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_EMPLEADOS_X_ID_EMPLEADO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EMPLEADOS.ID_EMPLEADO as ID_EMPLEADO,',
'    EMPLEADOS.ID_EMPLEADO||''-''||EMPLEADOS.NOMBRE ||'' ''||EMPLEADOS.PRIMER_APELLIDO ||'' ''||EMPLEADOS.SEGUNDO_APELLIDO as NOMBRE ',
' from EMPLEADOS EMPLEADOS, empleados_institucion_sirhp eis',
' where EMPLEADOS.ID_EMPLEADO = eis.ID_EMPLEADO and eis.INDICADOR_ACTIVO = 1;'))
,p_lov_display_null=>'YES'
,p_cSize=>50
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192290971348258099)
,p_name=>'P5_DATOS_EMPLEADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'<b>Datos Empleado:</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192291385964258100)
,p_name=>'P5_CEDULA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('Num. C\00E9dula:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192291736034258100)
,p_name=>'P5_NOMBRE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192292108011258100)
,p_name=>'P5_FECHA_NACIMIENTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Fecha Nacimiento:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192292524415258100)
,p_name=>'P5_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Email:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192292990341258100)
,p_name=>'P5_TEL_OFICINA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Tel Oficina:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192293326262258101)
,p_name=>'P5_DATOS_LABORALES'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'<b>Datos Laborales</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192293766992258101)
,p_name=>'P5_ID_DEPENDENCIA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>'Dependencia:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192294138957258101)
,p_name=>'P5_FECHA_ING_ADM_PUB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('Fecha Ing. Admi. P\00FAblica:')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'   style="border-style:none";'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192294563129258101)
,p_name=>'P5_ID_PUESTO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('N\00BA Puesto:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'style="border-style:none";'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192294916691258101)
,p_name=>'P5_FEC_ING_CARRERA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192295305861258101)
,p_name=>'P5_CLASIFICACION'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192295706355258102)
,p_name=>'P5_PROFESIONAL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192296198191258102)
,p_name=>'P5_ACREDIT_DE_VACAS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('<b>Acreditaci\00F3n de Vacaciones</b>')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192296537991258103)
,p_name=>'P5_FEC_ULT_ACREDIT'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(904747529287114915)
,p_prompt=>unistr('Fecha Ultima Acreditaci\00F3n')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(192302111512258119)
,p_validation_name=>'Valida si empleado es nulo'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P5_ID_EMPLEADO is null THEN',
'return false;',
'ELSE',
'return true;',
'END IF;'))
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Elija un empleado'
,p_associated_item=>wwv_flow_api.id(192290504956258093)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192302420386258120)
,p_name=>'DAC_REFRESH_ESCOLARIDAD'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_ID_EMPLEADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192302930363258122)
,p_event_id=>wwv_flow_api.id(192302420386258120)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vCedula VARCHAR2(20);',
'vNombre  VARCHAR2 (50);',
'vApellido1 VARCHAR2(20);',
'vApellido2 VARCHAR2(20);',
'vFechaNac DATE;',
'vTelefono VARCHAR2(10);',
'vEmail VARCHAR2(100);',
'vFechaIngAdmPubli DATE;',
'vFechaCarrera DATE;',
'vIdIncap_Emple NUMBER;',
'vIdPuesto VARCHAR2(50);',
'vDepartamento VARCHAR2(100);',
'vUltFechaAcred DATE;',
'        ',
'        CURSOR C_DATOS_EMPLEADO IS',
'        ',
'        SELECT E.CEDULA,E.NOMBRE,E.PRIMER_APELLIDO,E.SEGUNDO_APELLIDO,E.FECHA_NACIMIENTO,',
'        E.TELEFONO_OFICINA,E.EMAIL,E.FECHA_INGRESO_ADMIN_PUBLICA, EIS.FECHA_INGRESO_CARRERA,',
'        (SELECT DM.codigo_presupuestario FROM MOVIMIENTOS_PERSONAL MP INNER JOIN DETALLE_MOVIMIENTO DM ON ',
'         MP.ID_MOVIMIENTO_PERSONAL = DM.ID_MOVIMIENTO_PERSONAL WHERE MP.indicador_vigente = 1 and MP.ID_EMPLEADO = :P5_ID_EMPLEADO ) ',
'         as ID_PUESTO,',
'        (SELECT NOMBRE_DEPENDENCIA FROM MOVIMIENTOS_PERSONAL MP, DETALLE_MOVIMIENTO DM ',
'             where MP.ID_MOVIMIENTO_PERSONAL = DM.ID_MOVIMIENTO_PERSONAL and MP.ID_EMPLEADO = :P5_ID_EMPLEADO ',
'         and MP.indicador_vigente = 1) as DEPARTAMENTO,',
'        (select ULTIMA_ACREDITACION_VACACIONES from EMPLEADOS_INSTITUCION_SIRHP where ID_EMPLEADO = :P5_ID_EMPLEADO) as FVAC',
'        FROM   EMPLEADOS E, EMPLEADOS_INSTITUCION_SIRHP EIS',
'        WHERE  E.ID_EMPLEADO = EIS.ID_EMPLEADO',
'        AND E.ID_EMPLEADO = :P5_ID_EMPLEADO; ',
'        ',
'BEGIN',
'        ',
'        OPEN  C_DATOS_EMPLEADO;',
'        FETCH C_DATOS_EMPLEADO INTO vCedula,vNombre,vApellido1,vApellido2,vFechaNac,vTelefono,vEmail,vFechaIngAdmPubli,',
'        vFechaCarrera, vIdPuesto, vDepartamento, vUltFechaAcred;',
'        CLOSE C_DATOS_EMPLEADO;',
'        ',
'     :P5_PERIODO := TEST_RH_VACACIONES.PKG_UTILIDADES.RETORNA_PERIODO_HABIL(:P5_ID_EMPLEADO);',
'',
'        ',
'    :P5_CEDULA := vCedula;',
'    :P5_NOMBRE:= vNombre||'' ''||vApellido1||'' ''||vApellido2;',
'    :P5_FECHA_NACIMIENTO := vFechaNac;',
'    :P5_EMAIL := vEmail;',
'    :P5_TEL_OFICINA:= vTelefono;',
'    :P5_FECHA_ING_ADM_PUB := vFechaIngAdmPubli;',
'    :P5_FEC_ULT_ACREDIT := vUltFechaAcred;',
'    :P5_ID_DEPENDENCIA := vDepartamento;',
'    :P5_FEC_ING_CARRERA := vFechaCarrera;',
'    :P5_ID_PUESTO := vIdPuesto;',
'END;'))
,p_attribute_02=>'P5_ID_EMPLEADO'
,p_attribute_03=>'P5_CEDULA,P5_NOMBRE,P5_FECHA_NACIMIENTO,P5_EMAIL,P5_TEL_OFICINA,P5_FECHA_ING_ADM_PUB,P5_FEC_ULT_ACREDIT,P5_ID_DEPENDENCIA,P5_ID_PUESTO,P5_FEC_ING_CARRERA,P5_PERIODO'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192303480883258122)
,p_event_id=>wwv_flow_api.id(192302420386258120)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
