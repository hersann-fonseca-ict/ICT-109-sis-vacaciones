prompt --application/pages/page_00102
begin
--   Manifest
--     PAGE: 00102
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>102
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'ReporteVacacionesColecivas'
,p_alias=>'REPORTEVACACIONESCOLECIVAS'
,p_step_title=>'ReporteVacacionesColecivas'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241018122127'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195146390046523738)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188326824198098128)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'VACACIONES_COLECTIVAS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(195146761570523738)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP,:P103_ID_VACACION_COLECTIVA:#ID_VACACION_COLECTIVA#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>195146761570523738
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195146892270523743)
,p_db_column_name=>'ID_INSTITUCION_SIRHP'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id Institucion Sirhp'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195147255990523746)
,p_db_column_name=>'ID_VACACION_COLECTIVA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id Vacacion Colectiva'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195147689962523746)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195148030523523747)
,p_db_column_name=>'INDICADOR_INICIO_MEDIODIA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Indicador Inicio Mediodia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195148468852523747)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195148864299523747)
,p_db_column_name=>'INDICADOR_FINAL_MEDIODIA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Indicador Final Mediodia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195149281029523747)
,p_db_column_name=>'ESTADO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(57133992089856400)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195149644118523747)
,p_db_column_name=>'MOTIVO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195150079127523748)
,p_db_column_name=>'ID_MODIFICADOR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Modificador'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(189498657464576031)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(195150446645523748)
,p_db_column_name=>'FECHA_ULTIMA_MODIFICACION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('Fecha \00DAltima Modificaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(195153109619525443)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1951532'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_INSTITUCION_SIRHP:ID_VACACION_COLECTIVA:FECHA_INICIO:INDICADOR_INICIO_MEDIODIA:FECHA_FIN:INDICADOR_FINAL_MEDIODIA:ESTADO:MOTIVO:ID_MODIFICADOR:FECHA_ULTIMA_MODIFICACION'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304165895962642733)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Vacaciones Colectivas</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(195152535978523750)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(195146390046523738)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Registrar Vacaciones Colectivas'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:103'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(195151517864523749)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_ANIO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189312957025749220)
,p_event_id=>wwv_flow_api.id(195151517864523749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(195146390046523738)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(195152094714523750)
,p_event_id=>wwv_flow_api.id(195151517864523749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vFecha_inicio date;',
'vFecha_fin date;',
'vEstado char(1);',
'vMotivo VARCHAR2(250);',
'vFecha_Modificacion date;',
'',
'BEGIN',
'    SELECT FECHA_INICIO, FECHA_FIN, ESTADO, MOTIVO, FECHA_ULTIMA_MODIFICACION ',
'    INTO vFecha_inicio, vFecha_fin,vEstado, vMotivo, vFecha_Modificacion',
'    from DESA_RH.VACACIONES_COLECTIVAS where EXTRACT(YEAR FROM FECHA_INICIO) = :P102_ANIO;',
'    ',
'    :FECHA_INICIO := vFecha_inicio;',
'    :FECHA_FIN := vFecha_fin;',
'    :ESTADO := vEstado;',
'    :MOTIVO := vMotivo;',
'    :FECHA_ULTIMA_MODIFICACION := vFecha_Modificacion;',
'END;'))
,p_attribute_02=>'P102_ANIO'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
