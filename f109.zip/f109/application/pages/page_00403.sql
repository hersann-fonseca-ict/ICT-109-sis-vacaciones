prompt --application/pages/page_00403
begin
--   Manifest
--     PAGE: 00403
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>403
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'Reporte de Vacaciones que se puede modificar'
,p_alias=>'MODIFIQUEVACACIONES'
,p_page_mode=>'MODAL'
,p_step_title=>'Modifique sus Vacaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241101153334'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(54676201463189947)
,p_plug_name=>'Devolucion Vacaciones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188301375706098110)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id_empleado, ',
unistr('    CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA, sv.ESTADO_PROCESO',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv',
'where e.id_empleado = sv.id_empleado    and     sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'    and  e.cedula =  :P403_CEDULA',
'    and  sv.fecha_inicio >= (sysdate - 7)',
'    and sv.ESTADO_PROCESO = ''AP''',
'order by CAST(sv.fecha_inicio AS DATE) desc;',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P403_CEDULA'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte Devolucion Vacaciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>unistr('Devoluci\00F3n de Vacaciones')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(54676395378189947)
,p_name=>'ReporteDevolucionVacaciones'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No hay datos por mostrar'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>54676395378189947
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46298122703096926)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>unistr('Solicitar Devoluci\00F3n')
,p_column_link=>unistr('f?p=&APP_ID.:112:&SESSION.::&DEBUG.::P112_ID_EMPLEADO,P112_ID_SOLICITUD_VACACION,P112_PERIODO,P112_CANTIDAD_DE_DIAS,P112_DESDE,P112_HASTA,P112_ID_VACACION_COLECTIVA:#ID_EMPLEADO#,#ID_SOLICITUD_VACACION#,#PERIODO#,#Cantidad de D\00EDas#,#Desde#,#Hasta#,#I')
||'D_VACACION_COLECTIVA#'
,p_column_linktext=>'<img src="#APP_IMAGES#devolucion1.png" width= 25px>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54676756694189966)
,p_db_column_name=>'Desde'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Desde'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54677092033189976)
,p_db_column_name=>'Hasta'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Hasta'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54677497811189977)
,p_db_column_name=>unistr('Cantidad de D\00EDas')
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>unistr('Cantidad De D\00EDas')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54677842519189977)
,p_db_column_name=>'PERIODO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54678226995189977)
,p_db_column_name=>'ID_SOLICITUD_VACACION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('Id Solicitud Vacaci\00F3n')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54678611114189978)
,p_db_column_name=>'ID_VACACION_COLECTIVA'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>unistr('Id Vacaci\00F3n Colectiva')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54679062821189978)
,p_db_column_name=>'ESTADO_PROCESO'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Estado Proceso'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(57133992089856400)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(54680696458211554)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'546807'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID_EMPLEADO:Desde:Hasta:Cantidad de D\00EDas:PERIODO:ID_SOLICITUD_VACACION:ID_VACACION_COLECTIVA:ESTADO_PROCESO:')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(58164583653249231)
,p_plug_name=>'Eliminar Vacaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188301375706098110)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id_empleado, ',
unistr('    CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA, sv.ESTADO_PROCESO,',
' dv.INICIO_PERIODO',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv',
'where e.id_empleado = sv.id_empleado    and     sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'    and  e.cedula =  :P403_CEDULA',
'    and  sv.fecha_inicio >= (sysdate - 7)',
'    and sv.ESTADO_PROCESO = ''EA''',
'order by CAST(sv.fecha_inicio AS DATE) desc;',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P403_CEDULA'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'Eliminar Vacaciones'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(58164760362249233)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No hay datos por mostrar'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>58164760362249233
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165532030249241)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'Eliminar Solicitud'
,p_column_link=>unistr('f?p=&APP_ID.:113:&SESSION.::&DEBUG.::P113_ID_SOLICITUD,P113_ID_EMPLEADO,P113_DIAS,P113_PERIODO:#ID_SOLICITUD_VACACION#,#ID_EMPLEADO#,#Cantidad de D\00EDas#,#INICIO_PERIODO#')
,p_column_linktext=>'<img src="	#APP_IMAGES#basurero.png" width= 25px>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58164824229249234)
,p_db_column_name=>'Desde'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Desde'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58164916367249235)
,p_db_column_name=>'Hasta'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Hasta'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165053329249236)
,p_db_column_name=>unistr('Cantidad de D\00EDas')
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>unistr('Cantidad De D\00EDas')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165124520249237)
,p_db_column_name=>'PERIODO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165205097249238)
,p_db_column_name=>'ID_SOLICITUD_VACACION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('Id Solicitud Vacaci\00F3n')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165385543249239)
,p_db_column_name=>'ID_VACACION_COLECTIVA'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>unistr('Id Vacaci\00F3n Colectiva')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(58165409324249240)
,p_db_column_name=>'ESTADO_PROCESO'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Estado Proceso'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(57133992089856400)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(59081206041319421)
,p_db_column_name=>'INICIO_PERIODO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Inicio Periodo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(59091470011324138)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'590915'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID_EMPLEADO:Desde:Hasta:Cantidad de D\00EDas:PERIODO:ID_SOLICITUD_VACACION:ID_VACACION_COLECTIVA:ESTADO_PROCESO::INICIO_PERIODO')
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46298014828096925)
,p_name=>'P403_CEDULA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(54676201463189947)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
