prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>101
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'FormularioSolicitud'
,p_alias=>'FORMULARIOSOLICITUD'
,p_page_mode=>'MODAL'
,p_step_title=>'Solictud de vacaciones'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(188416823899098295)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>wwv_flow_api.id(188278682370098085)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241111115941'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(189479121938520510)
,p_plug_name=>'FormularioSolicitud'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_api.id(188297665893098103)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id_empleado, e.cedula, (e.nombre|| '' '' || e.primer_apellido || '' '' || e.segundo_apellido) as "Nombre Completo", ',
unistr('CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas"'),
'from DESA_RH.empleados e, DESA_RH.solicitudes_vacaciones_legales sv where e.id_empleado = sv.id_empleado',
'order by CAST(sv.fecha_inicio AS DATE) desc'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(189483791771520532)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188302348866098111)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189486166451520537)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(189483791771520532)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar solicitud'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P101_ID_EMPLEADO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189484162754520532)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(189483791771520532)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189485793615520537)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(189483791771520532)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189486566495520537)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(189483791771520532)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Solicitar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P101_ID_EMPLEADO'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46296817759096913)
,p_name=>'P101_PERIODO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Periodo'
,p_source=>'Nombre Completo'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46298205257096927)
,p_name=>'P101_ID_JEFE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_source=>'ID_EMPLEADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46298344265096928)
,p_name=>'P101_NOMBRE_JEFE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Jefatura actual'
,p_source=>'Nombre Completo'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389833543098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('Verificar el nombre de la jefatura est\00E9 correcto, de lo contrario comunicarse al departamento correspondiente')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189313748949749228)
,p_name=>'P101_MEDIO_DIA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>unistr('Medio D\00EDa')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;1'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189313814970749229)
,p_name=>'P101_TIPO_MEDIO_DIA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Tipo Medio Dia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Ma\00F1ana;M,Tarde;T')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189479595196520512)
,p_name=>'P101_ID_EMPLEADO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_source=>'ID_EMPLEADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189479937351520520)
,p_name=>'P101_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>unistr('C\00E9dula')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189480323742520523)
,p_name=>'P101_NOMBRE_COMPLETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Nombre'
,p_source=>'Nombre Completo'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189480766528520525)
,p_name=>'P101_DESDE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Desde'
,p_format_mask=>'dd/mm/yy'
,p_source=>'Desde'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>362
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189481153818520525)
,p_name=>'P101_HASTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_item_source_plug_id=>wwv_flow_api.id(189479121938520510)
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yy'
,p_source=>'Hasta'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>362
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189481538933520527)
,p_name=>'P101_CANTIDAD_DE_DIAS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Cantidad de D\00EDas')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(204710940191011104)
,p_name=>'P101_MENSAJE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(189479121938520510)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(189484215044520532)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(189484162754520532)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189485056878520535)
,p_event_id=>wwv_flow_api.id(189484215044520532)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(189311891080749209)
,p_name=>'DAC_CALCULA'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_HASTA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189311909531749210)
,p_event_id=>wwv_flow_api.id(189311891080749209)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number(10) := 0;',
'vfecha_actual varchar2(20);',
'vfecha_inicio varchar2(20);',
'vfecha_fin varchar2(20);',
'',
'BEGIN',
'    IF :P101_DESDE IS NOT NULL',
'    THEN',
'        IF :P101_HASTA IS NOT NULL THEN',
'          vfecha_inicio := To_DATE(:P101_DESDE, ''dd/mm/yy'');',
'            vfecha_fin := To_DATE(:P101_HASTA, ''dd/mm/yy'');',
'            vcantidaddias := TEST_RH_VACACIONES.PKG_UTILIDADES.DIAS_LABORABLES(vfecha_inicio, vfecha_fin);',
'            :P101_CANTIDAD_DE_DIAS := vcantidaddias;',
'            ',
'        END IF;',
'    END IF;',
'END;'))
,p_attribute_02=>'P101_CANTIDAD_DE_DIAS,P101_DESDE,P101_HASTA'
,p_attribute_03=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(190332549416442713)
,p_name=>'DAC_CALCULA1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_DESDE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(190332626360442714)
,p_event_id=>wwv_flow_api.id(190332549416442713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number(10) := 0;',
'vfecha_actual varchar2(20);',
'vfecha_inicio varchar2(20);',
'vfecha_fin varchar2(20);',
'',
'BEGIN',
'    IF :P101_DESDE IS NOT NULL',
'    THEN',
'        IF :P101_HASTA IS NOT NULL THEN',
'          vfecha_inicio := To_DATE(:P101_DESDE, ''dd/mm/yy'');',
'            vfecha_fin := To_DATE(:P101_HASTA, ''dd/mm/yy'');',
'            vcantidaddias := TEST_RH_VACACIONES.PKG_UTILIDADES.DIAS_LABORABLES(vfecha_inicio, vfecha_fin);',
'            :P101_CANTIDAD_DE_DIAS := vcantidaddias;         ',
'        END IF;',
'    END IF;',
'END;'))
,p_attribute_02=>'P101_DESDE,P101_HASTA,P101_CANTIDAD_DE_DIAS'
,p_attribute_03=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(189313934928749230)
,p_name=>'DAC_MEDIO_DIA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_MEDIO_DIA'
,p_condition_element=>'P101_MEDIO_DIA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189314074691749231)
,p_event_id=>wwv_flow_api.id(189313934928749230)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_TIPO_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189314161905749232)
,p_event_id=>wwv_flow_api.id(189313934928749230)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_TIPO_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189314347600749234)
,p_event_id=>wwv_flow_api.id(189313934928749230)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number := 0;',
'',
'BEGIN',
'    if :P101_CANTIDAD_DE_DIAS is not null',
'    then',
'        vcantidaddias := :P101_CANTIDAD_DE_DIAS;',
'        vcantidaddias := (vcantidaddias - 0.5);',
'        :P101_CANTIDAD_DE_DIAS := vcantidaddias;',
'    END IF;',
'END;'))
,p_attribute_02=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_03=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(189314494586749235)
,p_event_id=>wwv_flow_api.id(189313934928749230)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number := 0;',
'',
'BEGIN',
'    if :P101_CANTIDAD_DE_DIAS is not null',
'    then',
'        vcantidaddias := :P101_CANTIDAD_DE_DIAS;',
'        vcantidaddias := (vcantidaddias + 0.5);',
'        :P101_CANTIDAD_DE_DIAS := vcantidaddias;',
'    END IF;',
'END;'))
,p_attribute_02=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_03=>'P101_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(59082700092319436)
,p_name=>'DAC_MEDIODIA'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_CANTIDAD_DE_DIAS'
,p_condition_element=>'P101_CANTIDAD_DE_DIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59082890839319437)
,p_event_id=>wwv_flow_api.id(59082700092319436)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59082937200319438)
,p_event_id=>wwv_flow_api.id(59082700092319436)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_MEDIO_DIA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189487356463520538)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(189479121938520510)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form FormularioSolicitud'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(204712130460011116)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_Solicitud'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355) := '' '';',
'vRetorno boolean := false;',
'vmedioD_manana number := 0;',
'vmedioD_tarde number := 0;',
'begin',
'',
'    if :P101_MEDIO_DIA is null    then',
'        if :P101_TIPO_MEDIO_DIA = ''M'' then',
'            vmedioD_manana := 1;',
'        else',
'            vmedioD_tarde := 1;',
'         end if;',
'    end if;',
'     TEST_RH_VACACIONES.pkg_gestion.solicitud_vacaciones(:P101_ID_EMPLEADO, :P101_DESDE, :P101_HASTA, vmedioD_manana, vmedioD_tarde,',
'                                                         :P101_CANTIDAD_DE_DIAS, 0, null, ''EA'');',
'     ',
'     EXCEPTION',
'    WHEN OTHERS THEN',
unistr('        apex_error.add_error (p_message => ''Error al tramitar la boleta de vacaci\00F3n: ''|| SQLERRM,'),
'                              p_display_location => apex_error.c_inline_in_notification);',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(189486166451520537)
,p_process_success_message=>unistr('Solicitud enviada con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189487775124520539)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_process_success_message=>unistr('Solicitud enviada con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189486931149520538)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(189479121938520510)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FormularioSolicitud'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189314245907749233)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_CARGA_NOMBRE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vNombre VARCHAR2(100); vNombreJefe VARCHAR2(100);',
'vIdEmpleado NUMBER; vId_Jefe NUMBER; PRETORNO NUMBER;',
'PMENSAJE VARCHAR2(200);',
'',
' CURSOR C_NOM_EMPLEADO IS',
'            SELECT NOMBRE||'' ''||PRIMER_APELLIDO||'' ''||SEGUNDO_APELLIDO, ID_EMPLEADO',
'            FROM EMPLEADOS',
'            WHERE CEDULA = :P101_CEDULA;',
'',
'BEGIN',
'    IF :P101_CEDULA IS NOT NULL THEN',
'',
'            OPEN  C_NOM_EMPLEADO;',
'            FETCH C_NOM_EMPLEADO INTO vNombre, vIdEmpleado;',
'            CLOSE C_NOM_EMPLEADO;',
'        vId_Jefe :=  TEST_RH_VACACIONES.PKG_UTILIDADES.ID_JEFATURA(vIdEmpleado);',
'        vNombreJefe:= TEST_RH_VACACIONES.PKG_UTILIDADES.RETORNA_NOMBRE_EMP(vId_Jefe);',
'        :P101_NOMBRE_COMPLETO := vNombre;',
'        :P101_ID_EMPLEADO := vIdEmpleado;',
'        :P101_NOMBRE_JEFE := vNombreJefe;',
'        :P101_MENSAJE := '''';',
'     END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
