prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>112
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'MotivoDevolucion'
,p_alias=>'MOTIVODEVOLUCION'
,p_page_mode=>'MODAL'
,p_step_title=>'MotivoDevolucion'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241111150123'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(54689326674452021)
,p_plug_name=>unistr('Motivo de Devoluci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_api.id(188297665893098103)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id_empleado, ',
unistr('    CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA, sv.ESTADO_PROCESO',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv',
'where e.id_empleado = sv.id_empleado    and     sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'    and  e.cedula =  :P112_ID_EMPLEADO',
'    and  sv.ID_SOLICITUD_VACACION = :P112_ID_SOLICITUD_VACACION',
'    and  sv.fecha_inicio <= sysdate',
'order by CAST(sv.fecha_inicio AS DATE) desc;',
'',
''))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P112_ID_EMPLEADO,P112_ID_SOLICITUD_VACACION,P112_PERIODO,P112_CANTIDAD_DE_DIAS,P112_DESDE,P112_HASTA'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(59081389461319422)
,p_name=>'Devoluciones Registradas de esta boleta'
,p_parent_plug_id=>wwv_flow_api.id(54689326674452021)
,p_template=>wwv_flow_api.id(188301375706098110)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FECHA_INICIO, FECHA_FIN, DIAS_VACACIONES, INDICADOR_INICIO_MEDIODIA, INDICADOR_FINAL_MEDIODIA, ESTADO_PROCESO, ',
'FECHA_ULTIMA_MODIFICACION  from SOLICITUDES_VACACIONES_LEGALES where ID_SOLICITUD_DEVOLUCION_VACAC != 0 and ',
'    ID_SOLICITUD_DEVOLUCION_VACAC = :P112_ID_SOLICITUD_VACACION;'))
,p_read_only_when_type=>'ALWAYS'
,p_query_row_template=>wwv_flow_api.id(188355085398098151)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59081442936319423)
,p_query_column_id=>1
,p_column_alias=>'FECHA_INICIO'
,p_column_display_sequence=>1
,p_column_heading=>'Fecha Inicio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59081541410319424)
,p_query_column_id=>2
,p_column_alias=>'FECHA_FIN'
,p_column_display_sequence=>2
,p_column_heading=>'Fecha Fin'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59081618260319425)
,p_query_column_id=>3
,p_column_alias=>'DIAS_VACACIONES'
,p_column_display_sequence=>5
,p_column_heading=>'Dias Vacaciones'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59082310751319432)
,p_query_column_id=>4
,p_column_alias=>'INDICADOR_INICIO_MEDIODIA'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Media dia Ma\00F1ana')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Si;1,No;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59082418164319433)
,p_query_column_id=>5
,p_column_alias=>'INDICADOR_FINAL_MEDIODIA'
,p_column_display_sequence=>4
,p_column_heading=>'Media dia Tarde'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Si;1,No;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59081751055319426)
,p_query_column_id=>6
,p_column_alias=>'ESTADO_PROCESO'
,p_column_display_sequence=>6
,p_column_heading=>'Estado Proceso'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(57133992089856400)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(59081820970319427)
,p_query_column_id=>7
,p_column_alias=>'FECHA_ULTIMA_MODIFICACION'
,p_column_display_sequence=>7
,p_column_heading=>'Fecha Ultima Modificacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(59082661170319435)
,p_plug_name=>'SubTitulo'
,p_parent_plug_id=>wwv_flow_api.id(54689326674452021)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188302348866098111)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'Devoluciones Registradas de esta boleta'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(54695357010452041)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188302348866098111)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(54695732287452042)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(54695357010452041)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(54697310899452052)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(54695357010452041)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(54697781603452052)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(54695357010452041)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar a la jefatura'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P112_ID_SOLICITUD_VACACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(54698165487452053)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(54695357010452041)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P112_ID_SOLICITUD_VACACION'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46299152816096936)
,p_name=>'P112_MOTIVO'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Motivo de la solicitud de devoluci\00F3n')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(188390062570098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46300337845096948)
,p_name=>'P112_DESDE_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Desde Original'
,p_source=>'Desde'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46300495694096949)
,p_name=>'P112_HASTA_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Hasta Original'
,p_format_mask=>'dd/mm/yy'
,p_source=>'Hasta'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54689794252452022)
,p_name=>'P112_ID_SOLICITUD_VACACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>unistr('ID Solicitud Vacaci\00F3n')
,p_source=>'ID_SOLICITUD_VACACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54690196727452029)
,p_name=>'P112_ID_VACACION_COLECTIVA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>unistr('Id Vacaci\00F3n Colectiva')
,p_source=>'ID_VACACION_COLECTIVA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54690577270452031)
,p_name=>'P112_ID_EMPLEADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_source=>'ID_EMPLEADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54690920327452036)
,p_name=>'P112_DESDE'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Desde'
,p_source=>'Desde'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_02=>'&P112_DESDE.'
,p_attribute_03=>'&P112_HASTA.'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54691326665452037)
,p_name=>'P112_HASTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yy'
,p_source=>'Hasta'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_02=>'&P112_DESDE.'
,p_attribute_03=>'&P112_HASTA.'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54691790049452037)
,p_name=>'P112_CANTIDAD_DE_DIAS'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Cantidad de d\00EDas que va a devolver')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(54692140256452037)
,p_name=>'P112_PERIODO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Periodo'
,p_source=>'PERIODO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>83
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(56521756073724181)
,p_name=>'P112_MEDIO_DIA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Medio D\00EDa')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;1'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(56522037119729835)
,p_name=>'P112_TIPO_MEDIO_DIA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_prompt=>'Tipo Medio Dia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Ma\00F1ana;M,Tarde;T')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(56740776983143401)
,p_name=>'P112_MSJ_DEVOLUCION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_item_source_plug_id=>wwv_flow_api.id(54689326674452021)
,p_pre_element_text=>unistr('Seleccione el rango de los d\00EDas que desea devolver')
,p_source=>'ID_SOLICITUD_VACACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>300
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389556106098186)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'LEADING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(59081975152319428)
,p_name=>'P112_DEVOLUCIONES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(54689326674452021)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54695804285452042)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(54695732287452042)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54696656050452049)
,p_event_id=>wwv_flow_api.id(54695804285452042)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(46299238589096937)
,p_name=>'DAC_MEDIO_DIA'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_MEDIO_DIA'
,p_condition_element=>'P112_MEDIO_DIA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46299321680096938)
,p_event_id=>wwv_flow_api.id(46299238589096937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_TIPO_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46299438123096939)
,p_event_id=>wwv_flow_api.id(46299238589096937)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_TIPO_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46299593629096940)
,p_event_id=>wwv_flow_api.id(46299238589096937)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number := 0;',
'',
'BEGIN',
'    if :P112_CANTIDAD_DE_DIAS is not null',
'    then',
'        vcantidaddias := :P112_CANTIDAD_DE_DIAS;',
'        vcantidaddias := (vcantidaddias - 0.5);',
'        :P112_CANTIDAD_DE_DIAS := vcantidaddias;',
'    END IF;',
'END;'))
,p_attribute_02=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_03=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46299682752096941)
,p_event_id=>wwv_flow_api.id(46299238589096937)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number := 0;',
'',
'BEGIN',
'    if :P112_CANTIDAD_DE_DIAS is not null',
'    then',
'        vcantidaddias := :P112_CANTIDAD_DE_DIAS;',
'        vcantidaddias := (vcantidaddias + 0.5);',
'        :P112_CANTIDAD_DE_DIAS := vcantidaddias;',
'    END IF;',
'END;'))
,p_attribute_02=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_03=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(46299702520096942)
,p_name=>'DAC_CALCULA'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_DESDE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46299897721096943)
,p_event_id=>wwv_flow_api.id(46299702520096942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number(10) := 0;',
'vfecha_actual varchar2(20);',
'vfecha_inicio varchar2(20);',
'vfecha_fin varchar2(20);',
'',
'BEGIN',
'    IF :P112_DESDE IS NOT NULL',
'    THEN',
'        IF :P112_HASTA IS NOT NULL THEN',
'          vfecha_inicio := To_DATE(:P112_DESDE, ''dd/mm/yy'');',
'            vfecha_fin := To_DATE(:P112_HASTA, ''dd/mm/yy'');',
'            vcantidaddias := TEST_RH_VACACIONES.PKG_UTILIDADES.DIAS_LABORABLES(vfecha_inicio, vfecha_fin);',
'            :P112_CANTIDAD_DE_DIAS := vcantidaddias;         ',
'        END IF;',
'    END IF;',
'END;'))
,p_attribute_02=>'P112_DESDE,P112_HASTA'
,p_attribute_03=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(46299961113096944)
,p_name=>'DAC_CALCULA1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_HASTA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(46300096363096945)
,p_event_id=>wwv_flow_api.id(46299961113096944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'vcantidaddias number(10) := 0;',
'vfecha_actual varchar2(20);',
'vfecha_inicio varchar2(20);',
'vfecha_fin varchar2(20);',
'',
'BEGIN',
'    IF :P112_DESDE IS NOT NULL',
'    THEN',
'        IF :P112_HASTA IS NOT NULL THEN',
'          vfecha_inicio := To_DATE(:P112_DESDE, ''dd/mm/yy'');',
'            vfecha_fin := To_DATE(:P112_HASTA, ''dd/mm/yy'');',
'            vcantidaddias := TEST_RH_VACACIONES.PKG_UTILIDADES.DIAS_LABORABLES(vfecha_inicio, vfecha_fin);',
'            :P112_CANTIDAD_DE_DIAS := vcantidaddias;',
'            ',
'        END IF;',
'    END IF;',
'   -- :P112_CANTIDAD_DE_DIAS := 0.5;',
'END;'))
,p_attribute_02=>'P112_DESDE,P112_HASTA'
,p_attribute_03=>'P112_CANTIDAD_DE_DIAS'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(59082009856319429)
,p_name=>'DAC_MUESTRA DEVOLUCION'
,p_event_sequence=>50
,p_condition_element=>'P112_DEVOLUCIONES'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59083621894319445)
,p_event_id=>wwv_flow_api.id(59082009856319429)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(59082661170319435)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59083788624319446)
,p_event_id=>wwv_flow_api.id(59082009856319429)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(59082661170319435)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59082152291319430)
,p_event_id=>wwv_flow_api.id(59082009856319429)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(59081389461319422)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59082558437319434)
,p_event_id=>wwv_flow_api.id(59082009856319429)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(59081389461319422)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(59083009124319439)
,p_name=>'DAC_MEDIODIA'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_CANTIDAD_DE_DIAS'
,p_condition_element=>'P112_CANTIDAD_DE_DIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59083121051319440)
,p_event_id=>wwv_flow_api.id(59083009124319439)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_MEDIO_DIA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(59083219749319441)
,p_event_id=>wwv_flow_api.id(59083009124319439)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_MEDIO_DIA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(54698909332452055)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(54689326674452021)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form MotivoDevolucion'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(46300159112096946)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_SolicitarDevolucion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vCorreo varchar(50);',
'vNombre_Empleado varchar(100);',
'vCuerpo VARCHAR2(4000);',
'vId_Jefe number := 0;',
'PMENSAJE VARCHAR2(200);',
'vMedioDia varchar(100);',
'vmedioD_manana number := 0;',
'vmedioD_tarde number := 0;',
'    BEGIN',
'    ',
'        vId_Jefe := TEST_RH_VACACIONES.PKG_UTILIDADES.ID_JEFATURA(:P112_ID_EMPLEADO);',
'        vCorreo :=  TEST_RH_VACACIONES.PKG_UTILIDADES.OBTIENE_EMAIL_EMPLEADO(vId_Jefe);',
'        vNombre_Empleado :=  TEST_RH_VACACIONES.PKG_UTILIDADES.RETORNA_NOMBRE_EMP (:P112_ID_EMPLEADO);',
'        IF :P112_MEDIO_DIA = 1 THEN',
'            IF :P112_TIPO_MEDIO_DIA = ''M''    THEN',
unistr('                vMedioDia := ''ma\00F1ana'';'),
'                vmedioD_manana := 1;',
'            ELSE',
'                vMedioDia := ''tarde'';',
'                vmedioD_tarde := 1;',
'            END IF;',
unistr('        vCuerpo := ''Se notifica que ''|| vNombre_Empleado ||'' modific\00F3 la solicitud de vacaciones '' ||:P112_ID_SOLICITUD_VACACION||'', devolviendo los d\00EDas seg\00FAn el detalle: Medio d\00EDa (''||vMedioDia||'') del ''|| :P112_DESDE ||'' al ''|| :P112_HASTA ||''.'),
'Brindando el motivo de: ''||:P112_MOTIVO||''.',
unistr('Favor ingresar al sistema para aprobar o denegar la solicitud de devoluci\00F3n de vacaciones. '' || vCorreo;'),
'        ELSE',
unistr('        vCuerpo := ''Se notifica que ''|| vNombre_Empleado ||'' modific\00F3 la solicitud de vacaciones '' ||:P112_ID_SOLICITUD_VACACION||'', devolviendo los d\00EDas seg\00FAn el detalle: del ''|| :P112_DESDE ||'' al ''|| :P112_HASTA ||''.'),
'Brindando el motivo de: ''||:P112_MOTIVO||''.',
unistr('Favor ingresar al sistema para aprobar o denegar la solicitud de devoluci\00F3n de vacaciones. '' || vCorreo;'),
'        END IF;',
'        ',
'     --   raise_application_error(-20000,  :P112_CANTIDAD_DE_DIAS);',
'        TEST_RH_VACACIONES.pkg_gestion.solicitud_vacaciones(:P112_ID_EMPLEADO, :P112_DESDE, :P112_HASTA, vmedioD_manana, vmedioD_tarde, ',
'                                                            :P112_CANTIDAD_DE_DIAS, 0, null, ''DV'', :P112_ID_SOLICITUD_VACACION);',
unistr('       TEST_RH_VACACIONES.PKG_CORREOS.envio_correo (''adriana.rubio@ict.go.cr'',''Solicitud devoluci\00F3n vacaciones'',vCuerpo);'),
'         ',
'     EXCEPTION',
'    WHEN OTHERS THEN',
unistr('        apex_error.add_error (p_message => ''Error al solicitar la devoluci\00F3n del tiempo: ''|| SQLERRM,'),
'                              p_display_location => apex_error.c_inline_in_notification);',
'                              ',
'        end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(54697781603452052)
,p_process_success_message=>unistr('Solicitud de devoluci\00F3n enviada con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(54699334097452056)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(54698563836452053)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(54689326674452021)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form MotivoDevolucion'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(46300554353096950)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'vNumeroDevoluciones NUMBER := 0;',
'',
'BEGIN',
'',
':P112_DEVOLUCIONES:= null;',
'',
'IF :P112_DESDE IS NOT NULL    THEN',
'    IF :P112_HASTA IS NOT NULL    THEN',
'        :P112_HASTA_1 := :P112_HASTA;',
'        :P112_DESDE_1 := :P112_DESDE;',
'    END IF;',
'END IF;',
'',
'IF :P112_ID_SOLICITUD_VACACION IS NOT NULL THEN',
'',
'    select count(*) into vNumeroDevoluciones from SOLICITUDES_VACACIONES_LEGALES where ID_SOLICITUD_DEVOLUCION_VACAC != 0 and ',
'        ID_SOLICITUD_DEVOLUCION_VACAC = :P112_ID_SOLICITUD_VACACION;',
'    IF vNumeroDevoluciones > 0 THEN',
'        :P112_DEVOLUCIONES := vNumeroDevoluciones;',
'        END IF;',
'    END IF;',
'END;',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
