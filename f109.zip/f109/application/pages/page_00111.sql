prompt --application/pages/page_00111
begin
--   Manifest
--     PAGE: 00111
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>111
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'VACACIONES'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*    .t-Login-logo {',
'         background-image: url(#APP_IMAGES#Login.png) no repet;',
'         background-size: contain ;',
'        background-color: transparent;',
'         width: 403px;',
'         height: 405px;',
'        ',
'            }',
'*/',
'',
'.t-Login-logo {',
'         background-image: url(#APP_IMAGES#indice.png);',
'         background-size: cover;',
'         width: 100px;',
'         height: 100px;',
'            }',
'',
'.t-PageBody--login .t-Login-container { background-image: url(#APP_IMAGES#Playa.jpg); background-position: center center; background-repeat: no-repeat; background-attachment: fixed; background-size: cover; background-color: #45484d; background-color:'
||' -moz-linear-gradient(top, #45484d 0%, #000000 100%); background-color: -webkit-linear-gradient(top, #45484d 0%,#000000 100%); background-color: linear-gradient(to bottom, #45484d 0%,#000000 100%);}'))
,p_step_template=>wwv_flow_api.id(188280103277098088)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20240809115735'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(189950127375763024)
,p_plug_name=>'VACACIONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188327485782098128)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189952232531763026)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(189950127375763024)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ingresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189950580277763025)
,p_name=>'P111_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(189950127375763024)
,p_prompt=>'Usuario'
,p_placeholder=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(188389422226098185)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189950904229763025)
,p_name=>'P111_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(189950127375763024)
,p_prompt=>'Clave'
,p_placeholder=>'Clave'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(188389422226098185)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(189951374682763025)
,p_name=>'P111_REMEMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(189950127375763024)
,p_prompt=>'Recordar usuario'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOGIN_REMEMBER_USERNAME'
,p_lov=>'.'||wwv_flow_api.id(188418883644098307)||'.'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when_type=>'PLSQL_EXPRESSION'
,p_field_template=>wwv_flow_api.id(188389422226098185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
unistr('    Si usted selecciona esta opci\00F3n, la aplicaci\00F3n guardar\00E1 su nombre de usuario en una cookie del navegador. Cuando vuelva a ingresar en est\00E1 p\00E1gina, the campo de usuario estar\00E1 autom\00E1ticamente lleno.'),
'</p>',
'<p>',
unistr('    Si quita esta opci\00F3n y su nombre de usuario ya fue guardado previamente, se eliminar\00E1 el dato guardado.'),
'',
'</p>'))
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189953003821763027)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.send_login_username_cookie (',
'    p_username => lower(:P111_USERNAME),',
'    p_consent  => :P111_REMEMBER = ''Y'' );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189952645392763026)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P111_USERNAME,',
'    p_password => :P111_PASSWORD );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189953870669763027)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189953447918763027)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P111_USERNAME := apex_authentication.get_login_username_cookie;',
':P111_REMEMBER := case when :P111_USERNAME is not null then ''Y'' end;'))
);
wwv_flow_api.component_end;
end;
/
