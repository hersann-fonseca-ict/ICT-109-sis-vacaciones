prompt --application/pages/page_00400
begin
--   Manifest
--     PAGE: 00400
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>400
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'Reporte Detalle Periodo'
,p_alias=>'REPORTE-DETALLE-PERIODO'
,p_page_mode=>'MODAL'
,p_step_title=>'Reporte Detalle Periodo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20241018122242'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(199697570003763749)
,p_plug_name=>'Reporte Detalle Periodo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188301375706098110)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id_empleado, e.cedula, (e.nombre|| '' '' || e.primer_apellido || '' '' || e.segundo_apellido) as "Nombre Completo", ',
unistr('CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA, sv.ESTADO_PROCESO',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv',
'where e.id_empleado = sv.id_empleado    and     sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'    and  e.cedula =  :P400_CEDULA',
'    and  dv.INICIO_PERIODO = :P400_PERIODO_INICIO',
'    and dv.FIN_PERIODO = :P400_PERIODO_FIN',
'order by CAST(sv.fecha_inicio AS DATE) desc;',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_CEDULA,P400_PERIODO_INICIO,P400_PERIODO_FIN'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte Detalle Periodo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(199734055670846340)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>199734055670846340
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734168810846341)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id Empleado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734246284846342)
,p_db_column_name=>'CEDULA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734388316846343)
,p_db_column_name=>'Nombre Completo'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Completo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734451294846344)
,p_db_column_name=>'Desde'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734549488846345)
,p_db_column_name=>'Hasta'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734686058846346)
,p_db_column_name=>unistr('Cantidad de D\00EDas')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Cantidad De D\00EDas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734744762846347)
,p_db_column_name=>'PERIODO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734895993846348)
,p_db_column_name=>'ID_SOLICITUD_VACACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Id Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(199734987495846349)
,p_db_column_name=>'ID_VACACION_COLECTIVA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Id Vacaci\00F3n Colectiva')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46297652128096921)
,p_db_column_name=>'ESTADO_PROCESO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado Proceso'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(57133992089856400)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(199780793384871786)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1997808'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID_EMPLEADO:CEDULA:Nombre Completo:Desde:Hasta:Cantidad de D\00EDas:PERIODO:ID_SOLICITUD_VACACION:ID_VACACION_COLECTIVA:ESTADO_PROCESO')
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(199787769783623901)
,p_name=>'P400_CEDULA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(199697570003763749)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(199787895619623902)
,p_name=>'P400_PERIODO_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(199697570003763749)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(199787919942623903)
,p_name=>'P400_PERIODO_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(199697570003763749)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
