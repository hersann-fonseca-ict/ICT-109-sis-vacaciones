prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>109
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'ReporteVacacionesPendientes'
,p_alias=>'REPORTEVACACIONESPENDIENTES1'
,p_step_title=>'ReporteVacacionesPendientes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20240112145725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(213535481298397384)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188326824198098128)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct e.id_empleado, e.cedula, (e.nombre|| '' '' || e.primer_apellido || '' '' || e.segundo_apellido) as "Nombre Completo", ',
unistr('CAST(sv.fecha_inicio AS DATE)  as "Desde", CAST(sv.fecha_fin AS DATE) as "Hasta", sv.dias_vacaciones as "Cantidad de D\00EDas",'),
' dv.INICIO_PERIODO||'' - ''||dv.FIN_PERIODO PERIODO, sv.ID_SOLICITUD_VACACION, sv.ID_VACACION_COLECTIVA, sv.ESTADO_PROCESO,',
' sv.FECHA_REGISTRO, sv.ID_SUSTITUYE',
'from empleados e, solicitudes_vacaciones_legales sv, DISTRIBUCION_DIAS_VACACIONES dv,MOVIMIENTOS_PERSONAL MP, DETALLE_MOVIMIENTO DM ',
'where',
'      e.id_empleado = sv.id_empleado',
'and   sv.ID_SOLICITUD_VACACION = dv.ID_SOLICITUD_VACACION',
'and   e.id_empleado = MP.ID_EMPLEADO',
'and   MP.ID_MOVIMIENTO_PERSONAL = DM.ID_MOVIMIENTO_PERSONAL',
'and sv.ESTADO_PROCESO = ''EA''',
'and     DM.NOMBRE_DEPENDENCIA = (SELECT MAX(NOMBRE_DEPENDENCIA) FROM MOVIMIENTOS_PERSONAL MP, DETALLE_MOVIMIENTO DM ',
'where MP.ID_MOVIMIENTO_PERSONAL = DM.ID_MOVIMIENTO_PERSONAL and MP.ID_EMPLEADO = 620000002)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(213535851306397384)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:RP:P110_ID_SOLICITUD_VACACION:\#ID_SOLICITUD_VACACION#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>213535851306397384
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213538749646397377)
,p_db_column_name=>'ID_SOLICITUD_VACACION'
,p_display_order=>0
,p_column_identifier=>'H'
,p_column_label=>'Id Solicitud Vacacion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213535917334397380)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id Empleado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213536398479397379)
,p_db_column_name=>'CEDULA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213536785980397378)
,p_db_column_name=>'Nombre Completo'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Nombre Completo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213537185946397378)
,p_db_column_name=>'Desde'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213537529803397378)
,p_db_column_name=>'Hasta'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213537977383397378)
,p_db_column_name=>unistr('Cantidad de D\00EDas')
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Cantidad De D\00EDas')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213538313039397377)
,p_db_column_name=>'PERIODO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213539170318397377)
,p_db_column_name=>'ID_VACACION_COLECTIVA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Id Vacacion Colectiva'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213539585734397375)
,p_db_column_name=>'ESTADO_PROCESO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Estado Proceso'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213539982180397375)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(213540376064397375)
,p_db_column_name=>'ID_SUSTITUYE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Id Sustituye'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(213542706236396753)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2135428'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID_SOLICITUD_VACACION:ID_EMPLEADO:CEDULA:Nombre Completo:Desde:Hasta:Cantidad de D\00EDas:PERIODO:ID_VACACION_COLECTIVA:ESTADO_PROCESO:FECHA_REGISTRO:ID_SUSTITUYE')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1526399389842148965)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(188328765111098129)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Vacaciones Pendientes por Aprobar</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(213542314114397348)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(213535481298397384)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:110'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(213541368144397349)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(213535481298397384)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(213541822296397349)
,p_event_id=>wwv_flow_api.id(213541368144397349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(213535481298397384)
);
wwv_flow_api.component_end;
end;
/
