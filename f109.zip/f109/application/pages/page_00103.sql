prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>154470412228218006
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DESA_RH'
);
wwv_flow_api.create_page(
 p_id=>103
,p_user_interface_id=>wwv_flow_api.id(188413326638098235)
,p_name=>'FormularioVacacionesColectivas'
,p_alias=>'FORMULARIOVACACIONESCOLECTIVAS'
,p_page_mode=>'MODAL'
,p_step_title=>'Formulario Vacaciones Colectivas'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20240613095314'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195133116189523717)
,p_plug_name=>'Formulario Vacaciones Colectivas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188301375706098110)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'VACACIONES_COLECTIVAS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195141719017523728)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(188302348866098111)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(195142199573523728)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(195141719017523728)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(195143702014523735)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(195141719017523728)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(195144170428523736)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(195141719017523728)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aplicar Cambios'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(195144546466523736)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(195141719017523728)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(188390847665098191)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114357028254401)
,p_name=>'P103_ID_INSTITUCION_SIRHP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_source=>'ID_INSTITUCION_SIRHP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114424517254402)
,p_name=>'P103_INDICADOR_INICIO_MEDIODIA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_source=>'INDICADOR_INICIO_MEDIODIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114555599254403)
,p_name=>'P103_INDICADOR_FINAL_MEDIODIA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_source=>'INDICADOR_FINAL_MEDIODIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39115178289254409)
,p_name=>'P103_MODIFICADOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_prompt=>'Modificador'
,p_source=>'ID_MODIFICADOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195133505655523717)
,p_name=>'P103_ID_VACACION_COLECTIVA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_source=>'ID_VACACION_COLECTIVA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195134386793523722)
,p_name=>'P103_FECHA_INICIO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_prompt=>'Fecha Inicio'
,p_format_mask=>'dd/mm/yy'
,p_source=>'FECHA_INICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195135500324523724)
,p_name=>'P103_FECHA_FIN'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_prompt=>'Fecha Fin'
,p_format_mask=>'dd/mm/yy'
,p_source=>'FECHA_FIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195136764617523724)
,p_name=>'P103_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Aprobado;A,En estudio;E,Denegado;D'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195137197821523725)
,p_name=>'P103_MOTIVO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Motivo'
,p_source=>'MOTIVO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195137512248523725)
,p_name=>'P103_ID_MODIFICADOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_source=>'ID_MODIFICADOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(195137969076523725)
,p_name=>'P103_FECHA_ULTIMA_MODIFICACION'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(195133116189523717)
,p_item_source_plug_id=>wwv_flow_api.id(195133116189523717)
,p_prompt=>unistr('Fecha \00FAltima modificaci\00F3n')
,p_source=>'FECHA_ULTIMA_MODIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(188389733936098187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(195134815335523723)
,p_validation_name=>'P103_FECHA_INICIO must be timestamp'
,p_validation_sequence=>20
,p_validation=>'P103_FECHA_INICIO'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_api.id(195134386793523722)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(195136097141523724)
,p_validation_name=>'P103_FECHA_FIN must be timestamp'
,p_validation_sequence=>40
,p_validation=>'P103_FECHA_FIN'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_api.id(195135500324523724)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(195138473712523726)
,p_validation_name=>'P103_FECHA_ULTIMA_MODIFICACION must be timestamp'
,p_validation_sequence=>90
,p_validation=>'P103_FECHA_ULTIMA_MODIFICACION'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_api.id(195137969076523725)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(195142237462523728)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(195142199573523728)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(195143079791523734)
,p_event_id=>wwv_flow_api.id(195142237462523728)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(214241776814197539)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_Colectivas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P103_ID_VACACION_COLECTIVA IS NULL THEN',
'	TEST_RH_VACACIONES.PKG_COLECTIVAS.vacas_colectivas(NULL, :P103_FECHA_INICIO, :P103_FECHA_FIN, :P103_ESTADO, :P103_MOTIVO, ',
'                                         :P103_ID_MODIFICADOR);',
'ELSE',
'	TEST_RH_VACACIONES.PKG_COLECTIVAS.vacas_colectivas(:P103_ID_VACACION_COLECTIVA, :P103_FECHA_INICIO, :P103_FECHA_FIN, :P103_ESTADO,',
'                                         :P103_MOTIVO, :P103_ID_MODIFICADOR);',
'END IF;'))
,p_process_error_message=>'Error al ingresar los datos'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(195144546466523736)
,p_process_success_message=>'Vacaciones Colectivas Registradas'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(195144903150523736)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(195133116189523717)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FormularioVacacionesColectivas'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(189313631374749227)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_CARGA_DEFAULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vNombre VARCHAR2(100);',
'vId_Empleado number;',
'BEGIN',
'    ',
'    IF :P103_ID_VACACION_COLECTIVA IS NULL THEN',
'        :P103_FECHA_ULTIMA_MODIFICACION := SYSDATE;',
'        :P103_MODIFICADOR := :APP_USER;',
'        :P103_ID_MODIFICADOR := TEST_SEGURIDAD.PKG_UTILIDADES.FNC_GET_IDEMPLEADO(:APP_USER);',
'    ELSE',
'        vNombre := PLA_DATOS_GENERALES.FNC_NOMBRE_EMPLEADO(:P103_ID_MODIFICADOR);',
'        :P103_MODIFICADOR := :APP_USER;',
'    END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
